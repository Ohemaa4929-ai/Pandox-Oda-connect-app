# PANDOX ODA CONNECT

All-in-one marketplace platform for **Akim Oda, Eastern Region, Ghana** — connecting customers with drivers, delivery providers, hotels, short-stay and property providers. One shared backend + one database powering two interfaces.

| Interface | Production | Local dev |
|---|---|---|
| Customer / Provider app | `app.pandoxoda.com` | `http://localhost:3000/` |
| Owner Dashboard | `admin.pandoxoda.com` | `http://localhost:3000/admin` |

## Stack

- **Node.js 22** (built-in `node:sqlite` — no native build step)
- **Express 5** + `helmet`, `cookie-parser`, `express-rate-limit`
- **SQLite** (WAL mode) — single file database, zero external services
- **bcryptjs** password hashing (12 rounds), **jsonwebtoken** sessions, **otplib** TOTP 2FA
- **AES-256-GCM** encryption for national ID numbers (`ENCRYPTION_KEY`)
- **Paystack** (Ghana) — server-side verification + HMAC webhooks; **NOT CONFIGURED** until keys are set

## Quick start

```bash
npm install
cp .env.example .env        # then fill in real values
npm start
```

- Customer app: http://localhost:3000/
- Owner dashboard: http://localhost:3000/admin
- Health check: http://localhost:3000/api/health

The first run creates the owner account (SUPER_ADMIN) from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env`. Change those before going live.

## Tests

```bash
npm test
```

46 integration checks on a fresh test database (`data/test-pandox.db`).

## What's built (all 33 spec sections)

- **Auth & verification** — customer/provider registration, Ghana Card/Passport/Driver's Licence workflow (PENDING → UNDER_REVIEW → APPROVED/REJECTED), encrypted ID storage (AES-256-GCM)
- **Modules** — transportation/rides, delivery, hotels, Airbnb/short-stay, apartments/property with listings, rooms, vehicles, availability
- **Bookings** — rides, delivery, hotel nights, property; cancel per policy; ratings & reviews
- **Payments** — Paystack (Ghana), server-side verification + HMAC webhooks, never trusts frontend; **NOT CONFIGURED** until keys set
- **Financial ledger** — pending/successful/failed/cancelled/refunded/disputed; corrections create adjustment records, history never silently changed
- **Subscriptions** — customer + provider (3-month) plans, owner-configurable price/period/trial from dashboard
- **Commissions** — per-category percent + fixed fee, owner-configurable
- **Owner Dashboard** — 20 stat cards, users/providers/verifications/listings/bookings/disputes/transactions/refunds/subscriptions/commissions/reports, staff, audit log, sessions, settings, policies, campaigns, control center
- **Admin roles** — SUPER_ADMIN, FINANCE, VERIFICATION, SUPPORT, DISPUTE, CONTENT, TECH; strict server-side RBAC
- **Super admin security** — 2FA (TOTP), 12h sessions, rate limiting, login monitoring, session revocation, never hardcoded credentials
- **Audit log** — every admin action recorded, no modification path
- **Control center** — pause registrations/bookings/payments, disable modules, maintenance mode; all logged
- **Disputes** — raise, notes, investigate, resolve, close
- **13 legal policies** — versioned, acceptance tracking, reviewable for Ghanaian requirements
- **Notifications** — in-app always, email/SMS when configured, campaigns
- **Search & location** — search, filters, categories, city; maps when configured
- **Reports** — revenue/commission/provider earnings/bookings/users/providers/refunds/service performance by day/month/year
- **Security** — helmet headers, rate limiting, input validation, parameterized SQL, XSS-safe output, secure uploads

## Before go-live (external configuration)

| Item | Status | Action |
|---|---|---|
| Paystack keys + webhook | NOT CONFIGURED | Set `PAYSTACK_SECRET_KEY` etc., point webhook at `POST /api/payments/webhook/paystack` |
| SMTP email | NOT CONFIGURED | Set `SMTP_*` env vars |
| SMS provider | NOT CONFIGURED | Set `SMS_*` env vars |
| Maps | NOT CONFIGURED | Set `MAPS_API_KEY` |
| Domain + TLS | NOT CONFIGURED | Deploy behind HTTPS, `NODE_ENV=production` |
| Subscription prices & commissions | READY | Set from Owner Dashboard (seeded 0% / default plans) |
| Legal policies | SEEDED | Review 13 documents for Ghanaian requirements |
